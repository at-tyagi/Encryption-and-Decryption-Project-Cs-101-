# Decoding Project
Requirements: GNU C++ Compiler
To Run:

 - Move to code/ directory
 - Run `g++ main.cpp` and  `./a.out`

To Run autograder:
 - Move to code/ directory
 - Run `python3 autograder.py`
