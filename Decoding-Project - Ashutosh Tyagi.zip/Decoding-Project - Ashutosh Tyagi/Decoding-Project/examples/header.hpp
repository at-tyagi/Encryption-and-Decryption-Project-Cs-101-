#include<bits/stdc++.h>
using namespace std;
const string path_dict = "../examples/dictionary.txt";
const string path_file = "../test-cases/in/test-15-in.txt";
vector<char> freq_single = {'E', 'T', 'A', 'I'};
